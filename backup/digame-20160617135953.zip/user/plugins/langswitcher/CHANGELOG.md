# v1.2.1
## 05/28/2016

1. [](#bugfix)
    * Display all language names, even those with non supported locales
    
# v1.2.0
## 05/03/2016

1. [](#improved)
    * Take URI parameters into account when switching languages
    * Add `external` class to avoid problems on modular pages when `jquery.singlePageNav` is loaded  

# v1.1.0
## 10/15/2015

1. [](#improved)
    * Added active class to language links  

# v1.0.2
## 07/13/2015

1. [](#improved)
    * Improved homepage routing    

# v1.0.1
## 07/08/2015

1. [](#improved)
    * Updated blueprints with some typo fixes
    
# v1.0.0
## 07/08/2015

1. [](#new)
    * ChangeLog started...
