---
title: Home
menu: Home
metadata:
    description: Die Webbasierte Anleitung für DIGAME vom Zentrum elektronische Medien ZEM.
    keywords: DIGAME,ZEM,Zentrum elektronische Medien,Mediathek Admin,Mediathek,Bilddatenbank,Bildverwaltung,Bundesverwaltung,Eidgenossenschaft,Schweizerische Eidgenossenschaft,VBS,Bundesamt für Verteidigung, Bevölkerungsschutz und Sport
    author: Stefan Eckstein | Zentrum elektronische Medien (ZEM)
    robots: index, follow
process:
	twig: true
taxonomy:
    category: backendanleitung
    tag: [digame, Anleitung, ZEM]
visible: true
---

# Anleitung DIGAME
### Herzlich Willkommen bei der webbasierten Anleitung
<br>
<br>
> Tipp: Diese Website ist auch für mobile Endgeräte (Smartphones, Tablets) optimiert. Fügen Sie diese Seite am besten gleich zu Ihrem Homebildschirm hinzu.
