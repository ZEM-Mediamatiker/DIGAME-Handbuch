---
title: Mots-clés
slug: mots-cles
menu: Mots-clés
metadata:
    description: Die Webbasierte Anleitung für DIGAME vom Zentrum elektronische Medien ZEM.
    keywords: DIGAME,ZEM,Zentrum elektronische Medien,Mediathek Admin,Mediathek,Bilddatenbank,Bildverwaltung,Bundesverwaltung,Eidgenossenschaft,Schweizerische Eidgenossenschaft,VBS,Bundesamt für Verteidigung, Bevölkerungsschutz und Sport
    author: Stefan Eckstein | Zentrum elektronische Medien (ZEM)
    robots: index, follow
process:
	twig: true
taxonomy:
    category: backendanleitung
    tag: [digame, Anleitung, ZEM]
visible: true
---

## Mots-clés
***
Des mots-clés peuvent être attribués à une ressource numérique depuis l’arborescence (1). La sélection est représentée par une coche : si elle est blanche, cela signifie que la ressource correspond exactement au terme ; si elle est grise, cela signifie qu’un terme de cette sous-catégorie de l’arborescence a été attribué à la ressource. Pour sauvegarder l’attribution des mots-clés, l’utilisateur doit cliquer sur Sauvegarder [Speichern] (2) et pour la supprimer, il doit cliquer sur Interrompre [Abbrechen] (3).

<br>
{{ media['stichworte.png'].html() }}
###### Image n°28 : arborescence des mots-clés
<br>


<br>
***
