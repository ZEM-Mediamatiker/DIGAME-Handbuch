# v1.0.1
## 04/28/2015

1. [](#improved)
    * Added not about forward slash on route documentation
2. [](#bugfix)
    * Removed url validation on route from blueprints since it's not a url

# v1.0.0
## 04/04/2015

1. [](#new)
    * ChangeLog started...
